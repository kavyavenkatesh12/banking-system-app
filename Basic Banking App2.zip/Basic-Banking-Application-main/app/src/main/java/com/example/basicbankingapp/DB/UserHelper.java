package com.example.basicbankingapp.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.basicbankingapp.DB.UserContract.UserEntry;
import com.example.basicbankingapp.Data.User;

public class UserHelper extends SQLiteOpenHelper {

    String TABLE_NAME = UserEntry.TABLE_NAME;

    /** Name of the database file */
    private static final String DATABASE_NAME = "User.db";

    /**
     * Database version. If you change the database schema, you must increment the database version.*/
    private static final int DATABASE_VERSION = 1;

    public UserHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create a String that contains the SQL statement to create the pets table
        String SQL_CREATE_USER_TABLE =  "CREATE TABLE " + UserEntry.TABLE_NAME + " ("
                + UserEntry.COLUMN_USER_ACCOUNT_NUMBER + " INTEGER, "
                + UserEntry.COLUMN_USER_NAME + " VARCHAR, "
                + UserEntry.COLUMN_USER_EMAIL + " VARCHAR, "
                + UserEntry.COLUMN_USER_IFSC_CODE + " VARCHAR, "
                + UserEntry.COLUMN_USER_PHONE_NO + " VARCHAR, "
                + UserEntry.COLUMN_USER_ACCOUNT_BALANCE + " INTEGER NOT NULL);";

        // Execute the SQL statement
        db.execSQL(SQL_CREATE_USER_TABLE);

        // Insert Into Table
        db.execSQL("insert into " + TABLE_NAME + " values(8670,'Kavya', 'kavya@gmail.com','4575','8975641832', 15000)");
        db.execSQL("insert into " + TABLE_NAME + " values(5862,'Disha', 'disha@gmail.com','8749','8995641238', 5000)");
        db.execSQL("insert into " + TABLE_NAME + " values(5987,'Manasa', 'manasa@gmail.com','7796','7595645896', 5000)");
        db.execSQL("insert into " + TABLE_NAME + " values(8521,'Gowthami', 'gowthami@gmail.com','7732','9995640038', 8000)");
        db.execSQL("insert into " + TABLE_NAME + " values(1074,'Sahana', 'sahana@gmail.com','3009','9095648962', 7500)");
        db.execSQL("insert into " + TABLE_NAME + " values(2935,'Deepa', 'deepa@gmail.com','7785','8855640238', 6500)");
        db.execSQL("insert into " + TABLE_NAME + " values(8965,'Soujanya', 'soujanya@gmail.com','1317','8895640215', 4500)");
        db.execSQL("insert into " + TABLE_NAME + " values(6785,'Nuthan', 'nuthan@gmail.com','4522','9985021539', 2500)");
        db.execSQL("insert into " + TABLE_NAME + " values(9745,'Vindhya', 'vindhya@gmail.com','6542','9309565238', 10500)");
        db.execSQL("insert into " + TABLE_NAME + " values(3476,'Hari', 'hari@gmail.com','4550','8292591201', 9900)");
        db.execSQL("insert into " + TABLE_NAME + " values(8945,'Raj', 'raj@gmail.com','6256','9015641200', 9800)");
        db.execSQL("insert into " + TABLE_NAME + " values(4873,'Darshan', 'darshan@gmail.com','1113','9995641999', 11000)");
        db.execSQL("insert into " + TABLE_NAME + " values(1836,'Teju', 'teju@gmail.com','7766','9119541001', 5800)");
        db.execSQL("insert into " + TABLE_NAME + " values(2586,'Siri', 'siri@gmail.com','2326','6254642205', 3500)");
        db.execSQL("insert into " + TABLE_NAME + " values(8396,'Ganesh', 'ganesh@gmail.com','6962','6893641266', 1010)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion != newVersion) {
            // Simplest implementation is to drop all old tables and recreate them
            db.execSQL("DROP TABLE IF EXISTS " + UserEntry.TABLE_NAME);
            onCreate(db);
        }
    }

    public Cursor readAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from " + UserEntry.TABLE_NAME, null);
        return cursor;
    }

    public Cursor readParticularData (int accountNo) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from " + UserEntry.TABLE_NAME + " where " +
                                        UserEntry.COLUMN_USER_ACCOUNT_NUMBER + " = " + accountNo, null);
        return cursor;
    }

    public void updateAmount(int accountNo, int amount) {
        Log.d ("TAG", "update Amount");
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("update " + UserEntry.TABLE_NAME + " set " + UserEntry.COLUMN_USER_ACCOUNT_BALANCE + " = " + amount + " where " +
                UserEntry.COLUMN_USER_ACCOUNT_NUMBER + " = " + accountNo);
    }
}